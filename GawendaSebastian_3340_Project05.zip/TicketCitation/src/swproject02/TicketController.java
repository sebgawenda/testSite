/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swproject02;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;


/**
 *
 * @author utrgv
 */

public final class TicketController {
    TicketModel ticketModel;
    TicketView ticketView;
    
ArrayList<ParkedCar> ticketList = new ArrayList<>();   
   
    
    
    
    public TicketController(TicketModel ticketModel, TicketView ticketView)
    {
        this.ticketView = ticketView;
        this.ticketModel = ticketModel;
        this.attachHandlers();
        System.out.println("2");
    
    }
    
    
    
    public void attachHandlers()
    {
        //System.out.println("Debug 4");
        
        int bumpId = 0;
        
        
        /*
        ticketView.getClearAdd().setOnAction(e -> { 
            ticketView.clearAllAdd();
            });
        
        */
        
        
        
        
        
        ticketView.getAddTicket().setOnAction((ActionEvent e) -> {
            ParkedCar ticket = new ParkedCar();    
            System.out.println("3");
            
            ticket.setTicketNo(ticketView.getTicketNoTF().getText());
            
            
            ticket.setLicense(ticketView.getLicenseTF().getText());
            
            //String state = ticketView.getStateTF().getText();
            ticket.setState(ticketView.getStateTF().getText());
            
            //String permitNo = ticketView.getPermitTF().getText();
            ticket.setPermitNo(ticketView.getPermitTF().getText());
            
            //String make = ticketView.getMakeTF().getText();
            ticket.setMake(ticketView.getMakeTF().getText());
            
            String model = ticketView.getModelTF().getText();
            ticket.setModel(ticketView.getModelTF().getText());
            
            //String color = ticketView.getColorTF().getText();
            ticket.setColor(ticketView.getColorTF().getText());
            
            //String date = ticketView.getDateTF().getText();
            ticket.setDate(ticketView.getDateTF().getText());
            
            //String location = ticketView.getLocationTF().getText();
            ticket.setLocation(ticketView.getLocationTF().getText());
            
            //String time = ticketView.getTimeTF().getText();
            ticket.setTime(ticketView.getTimeTF().getText());
            
            //String issue = ticketView.getIssueTF().getText();
            ticket.setIssuedBy(ticketView.getIssueTF().getText());
            
            //String offense = "";
            //String list = "";
            
            if(ticketView.getToggleOffense().equals(ticketView.getNoPermitToggle()))
            {
                //offense = "No Permit";
                ticket.setOffense("No Permit");
            }
            else if(ticketView.getToggleOffense().equals(ticketView.getWrongSpotToggle()))
            {
                //offense = "Wrong Spot";
                ticket.setOffense("Wrong Spot");
            }
            else if(ticketView.getToggleOffense().equals(ticketView.getBadParkingToggle()))
            {
                //offense = "Bad Parking";
                ticket.setOffense("Bad Parking");
            }
            else
            {
                //offense = "Please see police station";
                ticket.setOffense("Please see police station");
            }
            
            /*
            list += "License: " + license + ", State: " + state
            + ", Permit No.: " + permitNo + ", Make: " + make + ", Model: "
            + model + ", Color: " + color + ", Date: " + date + ", Location: "
            + location + ", Time: " + time + ", Issued By: " + issue
            + "Offense" + offense;
            */
            
            
            
            System.out.println(ticket.toString());
            ticketList.add(ticket);
            ticketView.clearAllAdd();
            ticketModel.setCurrentTicket(ticket);
            ticketModel.addTicketDB(ticket);
            
            
        });

    ticketView.getPrintAll().setOnAction(e ->{
        ticketView.clearField();
        for(int i = 0; i != ticketList.size(); i++)
        {
            System.out.println("Ticket " +(i+1));
            
            
            
            ticketView.getPrintField().appendText("Ticket " +(i+1) + ticketModel.ticketList.get(i).toString());
            ticketView.getPrintField().appendText("\n");
            //System.out.println(ticketModel.ticketList.get(i).toString());
            //System.out.println("\n");
        }
    });
    
    ticketView.getRetrieveButton().setOnAction(e ->{
        
        ticketView.clearField();
        String ret = ticketView.getRetrieveTF().getText();
        ticketView.getPrintField().appendText(ticketModel.retrieveDB(ret).toString());
    });
    
    }

   
   
    
}
