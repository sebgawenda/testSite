/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swproject02;
import java.io.FileNotFoundException;
import java.io.IOException;
import static java.lang.System.in;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javafx.scene.layout.GridPane;


/**
 *
 * @author admin
 */
public class TicketModel extends GridPane {
    ArrayList<ParkedCar> ticketList = new ArrayList<>();
    ParkedCar ticket = new ParkedCar();
    Database db = Database.getSingletonOfdatabase();
    
    public void addTicketDB(ParkedCar ticket)
    {
        try{
            Connection conn = db.getConn();
            PreparedStatement prepStmnt = conn.prepareStatement("INSERT into ticket_table VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
        
            prepStmnt.setString(1, ticket.getTicketID());
            prepStmnt.setString(2, ticket.getLicense());
            prepStmnt.setString(3, ticket.getState());
            prepStmnt.setString(4, ticket.getPermitNo());
            prepStmnt.setString(5, ticket.getMake());
            prepStmnt.setString(6, ticket.getModel());
            prepStmnt.setString(7, ticket.getColor());
            prepStmnt.setString(8, ticket.getDate());
            prepStmnt.setString(9, ticket.getLocation());
            prepStmnt.setString(10, ticket.getTime());
            prepStmnt.setString(11, ticket.getIssuedBy());
            prepStmnt.setString(12, ticket.getOffense());
            prepStmnt.executeUpdate();   
        }
        catch (Exception e)
        {System.out.println("Error adding ticket to db: "+ e);}
    }
    
    
    public ParkedCar retrieveDB(String ticketID)
    {
        
        ParkedCar ticket = new ParkedCar();
        try
        {
            Statement stmt = db.getStmnt();
            ResultSet rs = db.getResul();
            
            rs = stmt.executeQuery("select * from ticket_table where ticketID = " + ticketID);
            rs.next();
            
            ticket = new ParkedCar(rs.getString("ticketID"), rs.getString("license"),
            rs.getString("state"), rs.getString("permit"), rs.getString("make"),
            rs.getString("model"), rs.getString("color"), rs.getString("date"),
            rs.getString("location"), rs.getString("time"), rs.getString("issuedBy"), 
            rs.getString("offense"));
            
        }
        catch (Exception e)
        {System.out.println("Error retrieving from db: "+ e);}
        return ticket;
    
    }
       

    public void setCurrentTicket(ParkedCar ticket)
    {
        this.ticket = ticket;
        ticketList.add(ticket);
    }
    
    public ParkedCar getCurrentTicket()
    {
        return this.ticket;
    }
    
    
    
    public ArrayList<ParkedCar> getCurrentTickets()
    {
        return this.ticketList;
    }
    
   
}
