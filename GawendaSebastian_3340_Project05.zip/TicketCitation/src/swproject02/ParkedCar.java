/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swproject02;

/**
 *
 * @author admin
 */
public class ParkedCar {

    ParkedCar(String string, String string0, String string1, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    public String getLicense() {
        return license;
    }
    public void setLicense(String license) {
        this.license = license;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getPermitNo() {
        return permitNo;
    }
    public void setPermitNo(String permitNo) {
        this.permitNo = permitNo;
    }
    public String getMake() {
        return make;
    }
    public void setMake(String make) {
        this.make = make;
    }
    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public String getIssuedBy() {
        return issuedBy;
    }
    public void setIssuedBy(String issuedBy) {
        this.issuedBy = issuedBy;
    }

    public ParkedCar(){}
    
    public ParkedCar(String ticketID, String license, String state, String permitNo, String make, String model, String color, String date, String location, String time, String issuedBy, String offense) {
        this.ticketID = ticketID;
        this.license = license;
        this.state = state;
        this.permitNo = permitNo;
        this.make = make;
        this.model = model;
        this.color = color;
        this.date = date;
        this.location = location;
        this.time = time;
        this.issuedBy = issuedBy;
        this.offense = offense;
    }
    
    private String ticketID;
    private String license;
    private String state;
    private String permitNo;
    private String make;
    private String model;
    private String color;
    private String date;
    private String location;
    private String time;
    private String issuedBy;
    private String offense;
    
    
    
    public String getOffense() {
        return offense;
    }

    public void setOffense(String offense) {
        this.offense = offense;
    }
    
    
    
  
    
    @Override
    public String toString() {
        return "Ticket #: "+ ticketID +"License: " + license + ", State: " + state 
                + ", Permit No.: " + permitNo + ", Make: " + make + ", Model: " 
                + model + ", Color: " + color + ", Date: " + date + ", Location: " 
                + location + ", Time: " + time + ", Issued By: " + issuedBy
                + "Offense: " + offense;
    }

    public String getTicketID() {
        return ticketID;
    }

    public void setTicketNo(String ticketID) {
        this.ticketID = ticketID;
    }

    
    
}
